@extends('includes.head')
@section('middle')

<div style="margin-left: 2%;margin-top: 3%; margin-right: 3%">
  {!! $page_content !!}
</div>


@endsection