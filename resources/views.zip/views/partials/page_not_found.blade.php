@extends('includes.head')
@section('middle')

<div style="margin-left: 2%;margin-top: 3%; margin-right: 3%">
    <h1 align="center">Data Not Found</h1>
</div>


@endsection